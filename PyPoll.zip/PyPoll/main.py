#import dependency 
import os
import csv

# path to collect data from local Resources folder
csvpath = os.path.join('Resources/election_data.csv')

# read in csv file and omit header
with open(csvpath, newline='') as csvfile:
    csvreader = csv.reader(csvfile, delimiter=',')
    header = next(csvreader) 

# initialize empty dictionary to store candidate and votes value
    candidate = {}
   
    # loop through the data
    for row in csvreader:
        
        # assign key element candidate, c, in candidate dictionary
        c = row[2] 

        # if candidate already exists in the dicionary, increment their vote total
        if c in candidate:
            candidate[c] += 1
        # otherwise, assign the initial vote count to 1
        else: 
            candidate[c] = 1
        
    # initialize each required value, assign vote as numerical value and candidate as string
    total_votes = 0
    max_votes = 0
    winner = ''

    # use build in function to get values from dictionary
    total_votes = sum(candidate.values())
    max_votes = max(candidate.values())

    # print first block analysis result
    print("-----------------------------------------------------------")
    print(f"Total votes: {total_votes}")
    print("------------------------------------------------------------")

    # loop though dictionary to extract each cnadidate percent vote, the cnadidate winner 
    # and votes for each candidate, then print the 2nd block of analysis result
    for c, votes in candidate.items():
        # calculate vote percent
        vote_percent = (votes / total_votes) * 100
        if(votes == max_votes):
            winner = c
        
        print(f"{c}: {round(vote_percent, 3)}% ({votes})")
        
    # print the 3rd block of analysis result
    print("--------------------------------------------------------------")
    print(f"Winner: {winner}")
    print("--------------------------------------------------------------")
