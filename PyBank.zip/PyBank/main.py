#import dependency 
import os
import csv

# path to collect data from local
# Resources folder
csvpath = os.path.join('Resources', 'budget_data.csv')

# initialize empty list 
date = []       # store the months data from row[0]
profit = []     # store the profit/losses value from row[1]
change = []     # store the profit/losses changes between the next month and the current month 

# read in csv file and omit header
with open(csvpath, newline='') as csvfile:
    csvreader = csv.reader(csvfile, delimiter=',')
    header = next(csvreader) 

# loop through the data to find total number of months, 
# total amount of profit/losses over the entire period
    for row in csvreader:
        
        date.append(row[0])
        total_months = len(date)
        
        profit.append(int(row[1]))

# use the last and the first profit/losses values to calculate
# the average profit/losses change over the entire period and rounded to 2 decimal

    lastProfit = profit[-1]     # find last profit/losses value in profit list
    firstProfit = profit[0]     # find first profit/losses value in profit list
    averageChange = round(float(lastProfit - firstProfit)/(total_months-1),2)   

# calculate the greatest profit increase and decrease over the entire period 
# and along the greatest profit changes date
    for i in range(len(date)):

        change.append(profit[i] - profit[i-1])      # add all changes from month to month to change list
        maxChange = max(change)         # find greatest increase change in change list
        minChange = min(change)         # find greatest decrease change in change list
        
        if profit[i] - profit[i-1] == maxChange:    # use condition to find greatest increase change index 
            maxIncre = profit[i] - profit[i-1]      # humer down the greatest increase value and date
            maxIncreDate = date[i]
        if profit[i] - profit[i-1] == minChange:    # use condition to find greatest decrease change index 
            maxDecre = profit[i] - profit[i-1]      # hammer down the greatest increase value and date
            maxDecreDate = date[i]  

# print out the analysis output
print("                                                          ")
print("Financial Analysis")
print("----------------------------------------------------------")
print(f"Total Months: {total_months}")
print(f"Total: ${sum(profit)}")
print(f"Average Change: ${averageChange}")
print(f"Greatest Increase in Profits: {maxIncreDate} (${maxIncre})") 
print(f"Greatest Decrease in Profits: {maxDecreDate} (${maxDecre})")
